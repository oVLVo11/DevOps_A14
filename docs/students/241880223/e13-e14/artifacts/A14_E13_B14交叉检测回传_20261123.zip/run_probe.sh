#!/usr/bin/env bash
set -euo pipefail

here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
out="${A14_E13_OUT:-$here/A14_cross_test}/probe"
tmp=$(mktemp -d)
trap 'rm -rf -- "$tmp"' EXIT
mkdir -p -- "$out"
git clone --quiet --branch codex/e13-b14-exchange "$here/B14_E13_exchange.bundle" "$tmp/repo"
git -C "$tmp/repo" checkout --quiet --detach 785f54324c915e4c4987cafea46a5ab0714be167
project="$tmp/repo/e13/projects/b14"
make -C "$project" clean > "$out/clean.log" 2>&1
make -C "$project" > "$out/initial-build.log" 2>&1
"$project/app" > "$out/initial-run.stdout"
sleep 1
sed -i 's/#define B14_ALERT_THRESHOLD 50/#define B14_ALERT_THRESHOLD 40/' "$project/alert_policy.h"
make -C "$project" > "$out/stale-build.log" 2>&1
"$project/app" > "$out/stale-run.stdout"
make -C "$project" clean > "$out/rebuild-clean.log" 2>&1
make -C "$project" > "$out/rebuild.log" 2>&1
make -C "$project" test EXPECTED_OUTPUT=2 > "$out/rebuild-test.log" 2>&1
"$project/app" > "$out/rebuild-run.stdout"
python3 - "$out" <<'PY'
import json,pathlib,sys
p=pathlib.Path(sys.argv[1])
observed={k:(p/f'{k}-run.stdout').read_text() for k in ('initial','stale','rebuild')}
ok=observed=={'initial':'1\n','stale':'1\n','rebuild':'2\n'}
(p/'probe.json').write_text(json.dumps({
  'status':'SUCCEEDED' if ok else 'FAILED',
  'source_commit':'785f54324c915e4c4987cafea46a5ab0714be167',
  'modified_file':'alert_policy.h',
  'change':'B14_ALERT_THRESHOLD 50 -> 40',
  'observed_stdout':observed,
  'all_exit_codes':0,
},ensure_ascii=False,indent=2)+'\n')
if not ok: raise SystemExit(1)
PY
