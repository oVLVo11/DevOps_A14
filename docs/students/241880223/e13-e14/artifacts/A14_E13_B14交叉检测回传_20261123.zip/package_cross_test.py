"""Check and package A14's independent E13 run against the B14 Git bundle."""

import hashlib
import json
import pathlib
import subprocess
import zipfile


HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent.parent
RUN = HERE / "A14_cross_test"
OUT = ROOT / "A14_E13_B14交叉检测回传_20261123.zip"
BASE = "db7ad8c0df5f8801b4147f3d204610bd6400bd4b"
TARGET = "785f54324c915e4c4987cafea46a5ab0714be167"
EXPECTED = [{"type": "MISSING", "target": "helper.o", "dependency": "alert_policy.h"}]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def normalized(findings):
    return [{k: f[k] for k in ("type", "target", "dependency")} for f in findings]


result = read_json(RUN / "pipeline/result.json")
incremental = read_json(RUN / "pipeline/incremental-report.json")
base = read_json(RUN / "pipeline/baseline-full/findings.json")
target = read_json(RUN / "pipeline/target-full/findings.json")
probe = read_json(RUN / "probe/probe.json")
source = read_json(RUN / "pipeline/incremental-check.json")
assert result["status"] == "SUCCEEDED"
assert result["base_commit"] == BASE and result["target_commit"] == TARGET
assert source["job_id"] == result["job_id"] and source["trace_id"] == result["trace_id"]
assert source["commit"] == TARGET and source["kind"] == "incremental-check"
assert base["status"] == target["status"] == "SUCCEEDED"
assert base["findings"] == []
assert incremental["findings"] == EXPECTED
assert normalized(target["findings"]) == EXPECTED
assert probe["status"] == "SUCCEEDED"
for version in ("base", "target"):
    assert (RUN / f"build-check/{version}-run.stdout").read_bytes() == b"1\n"
    assert (RUN / f"build-check/{version}-source-diff.log").read_bytes() == b""

source_bytes = (RUN / "pipeline/incremental-check.json").read_bytes()
fixed = {
    "schema_version": "e11e12-1",
    "kind": "fixed-md",
    "status": "SUCCEEDED",
    "commit": TARGET,
    "data": incremental,
    "source_report": {
        "job_id": result["job_id"],
        "trace_id": result["trace_id"],
        "uri": f"artifact://{result['job_id']}/incremental-check.json",
        "sha256": sha(source_bytes),
    },
}
write_json(RUN / "fixed-md.json", fixed)
a14_sha = subprocess.check_output(
    ["git", "-c", f"safe.directory={ROOT / 'DevOps_A14'}", "rev-parse", "HEAD"],
    cwd=ROOT / "DevOps_A14", text=True,
).strip()
coordinates = read_json(HERE / "coordinates.json")
summary = {
    "schema": "A14_B14_E13_CROSS_TEST_1",
    "status": "SUCCEEDED",
    "execution_scope": "NATIVE_UBUNTU_WSL_NO_B14_DOCKER_IMAGE",
    "a14_source_commit": a14_sha,
    "input_archive_sha256": sha((ROOT / "发给A14_B14-E13交换项目.zip").read_bytes()),
    "input_bundle_sha256": sha((HERE / "B14_E13_exchange.bundle").read_bytes()),
    "b14_source_repository_commit": coordinates["source_repository_commit"],
    "b14_project_path": "e13/projects/b14",
    "base_commit": BASE,
    "target_commit": TARGET,
    "job_id": result["job_id"],
    "trace_id": result["trace_id"],
    "baseline_dynamic_trace_id": base["trace_id"],
    "target_dynamic_trace_id": target["trace_id"],
    "baseline_findings": [],
    "target_incremental_findings": EXPECTED,
    "target_dynamic_findings": EXPECTED,
    "base_and_target_stdout": "1\n",
    "unpatched_header_probe": probe["observed_stdout"],
    "fixed_md_sha256": sha((RUN / "fixed-md.json").read_bytes()),
    "fixed_md_path": "A14_cross_test/fixed-md.json",
    "evidence_directory": "A14_cross_test/pipeline",
    "b14_configuration_id": None,
    "b14_image_ref": None,
    "pending": "B14 official container rerun and configuration_id; joint E13 sign-off",
}
write_json(RUN / "handoff-summary.json", summary)
readme = f"""# A14 → B14：E13 交换项目独立交叉检测

使用 B14 交接 ZIP（SHA-256 `{summary['input_archive_sha256']}`）中的完整 Git bundle（SHA-256 `{summary['input_bundle_sha256']}`），从两个固定提交在 Ubuntu WSL 中独立运行 A14 `labs/e11e12/pipeline.py`，模式 `e11-a`。A14 检测代码提交：`{a14_sha}`。

- Base `{BASE}`：`make clean && make && make test && ./app` 输出精确 `1\\n`，BuildChecker 全量发现 0。
- Target `{TARGET}`：同样输出 `1\\n`；EChecker 教学增量报告和 BuildChecker 动态全量对照均发现唯一 `MISSING(helper.o, alert_policy.h)`。
- A14 Job ID：`{result['job_id']}`；本轮 Trace ID：`{result['trace_id']}`。BuildChecker 两次动态 trace ID 分别为 `{base['trace_id']}`、`{target['trace_id']}`。
- 单独从干净 Target 检出作头文件探针：阈值 `50 -> 40` 后普通增量构建仍输出 `1`，干净重构输出 `2`；见 `A14_cross_test/probe/`。
- 供 B14 继续消费的 E13 `fixed-md.json` SHA-256：`{summary['fixed_md_sha256']}`；其中 `source_report` 指向本轮原始 `incremental-check.json` 并记录字节哈希。

原始结果、图、Make 数据库、strace、构建与运行日志保存在 `A14_cross_test/`；`SHA256SUMS.txt` 是本 ZIP 内每个文件的哈希清单。复现脚本 `run_cross_test.sh` 和 `run_probe.sh` 随包附上，需要原交接 ZIP 中的 bundle 放在脚本同目录。重跑时将 `A14_REPO` 指向 A14 仓库克隆，把 `A14_E13_OUT` 指向新的空目录，例如 `A14_REPO=/path/to/DevOps_A14 A14_E13_OUT=/tmp/a14-b14-e13-rerun bash run_cross_test.sh`，然后以同一个 `A14_E13_OUT` 运行 `run_probe.sh`。

本轮为原生 Ubuntu 检测，B14 容器镜像和 `configuration_id` 尚未提供，因此没有声称同镜像检测或双方最终签收。B14 完成候选 Dockerfile 的正式容器复跑后，请回传镜像 ID/digest、`configuration_id`、构建/测试/运行原始日志与退出码、服务源码 SHA、结果清单和哈希。双方据此签收。
"""
(RUN / "README_for_B14.md").write_text(readme, encoding="utf-8")

entries = {}
for path in sorted(RUN.rglob("*")):
    if path.is_file() and ".git" not in path.relative_to(RUN).parts and path.name != "SHA256SUMS.txt":
        entries[f"A14_cross_test/{path.relative_to(RUN).as_posix()}"] = path.read_bytes()
for name in ("run_cross_test.sh", "run_probe.sh", "package_cross_test.py", "coordinates.json"):
    entries[name] = (HERE / name).read_bytes()
sums = "".join(f"{sha(data)}  {name}\n" for name, data in sorted(entries.items()))
entries["SHA256SUMS.txt"] = sums.encode("utf-8")
with zipfile.ZipFile(OUT, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(entries.items()):
        z.writestr(name, data)
with zipfile.ZipFile(OUT) as z:
    assert z.testzip() is None
    assert all(sha(z.read(name)) == digest for digest, name in
               (line.split("  ", 1) for line in z.read("SHA256SUMS.txt").decode("utf-8").splitlines()))
print(json.dumps({"package": str(OUT), "package_sha256": sha(OUT.read_bytes()),
                  "files": len(entries), "bytes": OUT.stat().st_size,
                  "job_id": result["job_id"], "trace_id": result["trace_id"],
                  "fixed_md_sha256": summary["fixed_md_sha256"]}, ensure_ascii=False, indent=2))
