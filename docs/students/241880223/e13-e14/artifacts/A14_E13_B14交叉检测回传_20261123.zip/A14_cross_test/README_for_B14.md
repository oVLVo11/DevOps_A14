# A14 → B14：E13 交换项目独立交叉检测

使用 B14 交接 ZIP（SHA-256 `a1fec5e8368f412990f5dfd4cde501581558b3bfaa13b127e29c5556c7aded2a`）中的完整 Git bundle（SHA-256 `8d43cd7767c7488965644ae4aa7411b02719f5d16c7de42afdfdbf580dd3e558`），从两个固定提交在 Ubuntu WSL 中独立运行 A14 `labs/e11e12/pipeline.py`，模式 `e11-a`。A14 检测代码提交：`7a0aa8f0558c989c13203c7bb8bf6c2358163059`。

- Base `db7ad8c0df5f8801b4147f3d204610bd6400bd4b`：`make clean && make && make test && ./app` 输出精确 `1\n`，BuildChecker 全量发现 0。
- Target `785f54324c915e4c4987cafea46a5ab0714be167`：同样输出 `1\n`；EChecker 教学增量报告和 BuildChecker 动态全量对照均发现唯一 `MISSING(helper.o, alert_policy.h)`。
- A14 Job ID：`job-887335840f5d469a95ecac4de93ea32b`；本轮 Trace ID：`trace-a84032f2c6cd445eb34c5704052e27b7`。BuildChecker 两次动态 trace ID 分别为 `e6-d31a4002e0894200a2c0e0810f887cc2`、`e6-8a4a0ed8e9274a25b25e785d39112b94`。
- 单独从干净 Target 检出作头文件探针：阈值 `50 -> 40` 后普通增量构建仍输出 `1`，干净重构输出 `2`；见 `A14_cross_test/probe/`。
- 供 B14 继续消费的 E13 `fixed-md.json` SHA-256：`cfd2889a3e5c068f14f49d602e1c52e8cb8dd069bdd405f6e5e1f39ca66df118`；其中 `source_report` 指向本轮原始 `incremental-check.json` 并记录字节哈希。

原始结果、图、Make 数据库、strace、构建与运行日志保存在 `A14_cross_test/`；`SHA256SUMS.txt` 是本 ZIP 内每个文件的哈希清单。复现脚本 `run_cross_test.sh` 和 `run_probe.sh` 随包附上，需要原交接 ZIP 中的 bundle 放在脚本同目录。重跑时将 `A14_REPO` 指向 A14 仓库克隆，把 `A14_E13_OUT` 指向新的空目录，例如 `A14_REPO=/path/to/DevOps_A14 A14_E13_OUT=/tmp/a14-b14-e13-rerun bash run_cross_test.sh`，然后以同一个 `A14_E13_OUT` 运行 `run_probe.sh`。

本轮为原生 Ubuntu 检测，B14 容器镜像和 `configuration_id` 尚未提供，因此没有声称同镜像检测或双方最终签收。B14 完成候选 Dockerfile 的正式容器复跑后，请回传镜像 ID/digest、`configuration_id`、构建/测试/运行原始日志与退出码、服务源码 SHA、结果清单和哈希。双方据此签收。
