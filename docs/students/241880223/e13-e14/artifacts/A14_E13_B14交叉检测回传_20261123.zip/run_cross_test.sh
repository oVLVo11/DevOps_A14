#!/usr/bin/env bash
set -euo pipefail

here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
root=$(cd -- "$here/../.." && pwd)
a14="${A14_REPO:-$root/DevOps_A14}"
bundle="$here/B14_E13_exchange.bundle"
out="${A14_E13_OUT:-$here/A14_cross_test}"
base=db7ad8c0df5f8801b4147f3d204610bd6400bd4b
target=785f54324c915e4c4987cafea46a5ab0714be167
tmp=$(mktemp -d)
trap 'rm -rf -- "$tmp"' EXIT
mkdir -p -- "$out/input-check" "$out/build-check"

git clone --quiet --branch codex/e13-b14-exchange "$bundle" "$tmp/b14-exchange"
git -C "$tmp/b14-exchange" bundle verify "$bundle" > "$out/input-check/bundle-verify.log" 2>&1
git -C "$tmp/b14-exchange" fsck --full --no-dangling > "$out/input-check/git-fsck.log" 2>&1
git -C "$tmp/b14-exchange" merge-base --is-ancestor "$base" "$target"
git -C "$tmp/b14-exchange" rev-parse "$base^{commit}" "$target^{commit}" > "$out/input-check/commit-shas.log"

for phase in base target; do
  if [[ "$phase" == base ]]; then sha=$base; else sha=$target; fi
  git -C "$tmp/b14-exchange" checkout --quiet --detach "$sha"
  project="$tmp/b14-exchange/e13/projects/b14"
  make -C "$project" clean > "$out/build-check/$phase-clean.log" 2>&1
  make -C "$project" > "$out/build-check/$phase-build.log" 2>&1
  make -C "$project" test > "$out/build-check/$phase-test.log" 2>&1
  "$project/app" > "$out/build-check/$phase-run.stdout" 2> "$out/build-check/$phase-run.stderr"
  [[ "$(cat "$out/build-check/$phase-run.stdout")" == 1 ]]
  git -C "$tmp/b14-exchange" diff --exit-code -- e13/projects/b14 > "$out/build-check/$phase-source-diff.log"
done

python3 - "$out/request.json" "$tmp/b14-exchange" <<'PY'
import json,sys
request={
  'mode':'e11-a',
  'repo':sys.argv[2],
  'base':'db7ad8c0df5f8801b4147f3d204610bd6400bd4b',
  'target':'785f54324c915e4c4987cafea46a5ab0714be167',
  'project_path':'e13/projects/b14',
  'expected_output':'1',
}
with open(sys.argv[1],'w',encoding='utf-8') as f:
  json.dump(request,f,ensure_ascii=False,indent=2)
  f.write('\n')
PY

PYTHONPATH="$a14/labs/e8e10/environment/services/buildchecker${PYTHONPATH:+:$PYTHONPATH}" \
  python3 "$a14/labs/e11e12/pipeline.py" --request "$out/request.json" \
  --out "$out/pipeline" > "$out/pipeline-stdout.json" 2> "$out/pipeline-stderr.log"
python3 - "$out/pipeline/result.json" <<'PY'
import json,sys
r=json.load(open(sys.argv[1],encoding='utf-8'))
print(json.dumps({k:r[k] for k in ('status','job_id','trace_id','base_commit','target_commit')},indent=2))
if r['status']!='SUCCEEDED': raise SystemExit(1)
PY
