# 输入材料与版本来源

## A14 仓库

- URL：`https://github.com/oVLVo11/DevOps_A14.git`
- 检查日期：2026-09-25
- 初始状态：检查时远程为空仓库
- 发布状态：E2 材料由刘威 commit 并 push 到 A14 GitHub `main`；完整 commit SHA 在交接消息中提供

## B14 仓库

- URL：`https://github.com/dInG-yAnWen/DevOPs.git`
- 检查日期：2026-09-25
- E2 1.0 固定基线：`ef50c0f6a64ce74d6f2cca5a9b968aedbb0b5856`
- 基线提交标题：`fix(e2): preserve artifact bytes across Git exports`
- 原始 E2 发布提交：`689539119e60afd4b224d3163d1ba292992baa95`（存在 Git 换行规范化导致的产物摘要复现问题，已由新基线修复）
- 说明：修复提交增加 `/contracts/artifacts/** -text` 和验证记录；Schema、接口字段、manifest 摘要值及产物原始内容均未修改。
- A14 复核：从新基线执行 Git 原始导出后，19 份产物摘要一致，解压后的 69 项检查全部通过。

## B14 协作包

- 文件：`DevOPs.zip`
- SHA-256：`1858D6521DBF4A6AC75A6FD55CB2B32FAC77A812D09D28190FFF262AD2715448`
- 内容：统一 Schema、API 说明、四类任务样例、人工产物、manifest、校验器、Backlog 与 ADR
- 使用方式：A14 采用其中的 1.0 契约作为协作基线，并新增 A14 责任说明和验收记录
- 发布对应：B14 完整 E2 契约及字节一致性修复对应 `ef50c0f6a64ce74d6f2cca5a9b968aedbb0b5856`

## 课程材料

- `E2_需求与接口契约_20260910.pptx`：E2 范围、四服务协作、统一 Job、状态、错误、产物、校验和过程材料要求
- `E3_并行测试基线_20260910.pptx`：E3 真实项目与并行测试准备，未作为 E2 真实运行证据
- `A14_协作确认消息.md`：B14 向 A14 提出的 DRAFT 契约与资料请求

## 论文材料

- `_TSE__BuildChecker.pdf`
- `_ISSTA_2024__Detecting_Build_Dependency_Error.pdf`
- `_ICSE_2026__Dockerfile_auto_generation.pdf`
- `_ASE_2025__Auto_fix_missing_dependency_errors.pdf`

论文只作为系统职责、输入输出和算法边界依据。本 E2 包不声称复现实验指标。
