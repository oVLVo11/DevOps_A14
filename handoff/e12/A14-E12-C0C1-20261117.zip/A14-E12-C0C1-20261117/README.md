# A14 → B14，E12 第一轮检测原件

本包对应 `trace-3ccaf76e466544e9b78f08a0ddffea67`、B14 DRAFT Job `job-6f84eaab4b3846eca3f95043a31ff30c` 和 `session.json` 中的配置 ID。A14 于 2026-11-17 在课程 Linux 服务器导入 B14 的已校验 `image.tar`；导入镜像 ID 与 B14 清单一致。镜像运行 C1 为 `12`。在同一原始镜像启动的独立容器中，C0/C1 执行 `make clean && make && ./app` 分别得到 `10` 和 `12`。

检测使用 A14 提交 `44fb20ea57645a6d40b37638b699d6c2cacbe19b`。容器关闭网络，使用镜像内的 Python 3、GCC 14.2 和 Make 4.4.1。由于 B14 镜像未安装 Git/strace，A14 将服务器上的 Git 2.34.1、strace 5.16 和所需 libunwind 只读挂载到容器；见 `toolchain.txt`、`tool-mounts.sha256`。镜像本身未重建。尝试在容器内安装 Git 的未完成日志保留在 A14 服务器，未计为本轮检测。

## B14 消费入口

- `session.json`：本轮 trace、DRAFT/检测 Job、配置、提交、镜像与实际运行信息。
- `a14-check/handoff.json`：C0 全量、C1 增量的 URI 和发现差分。
- `a14-check/manifest.json`：七个 `artifact://` URI 对应的相对路径和 SHA-256。URI 的解析根目录是 `a14-check/`。
- C1 MD-only 1.0 报告：`a14-check/artifacts/a14-check/job-22c9005a7b0e42f9bdc48078420a9d91/md.json`，SHA-256 为 `2aead6b279506a1c689873a1d660e2f8902f4dc11ee3fdcf9b3b170c4be64ea5`。仅有 `MISSING(main.o, feature.h)`，提交为指定 C1，已通过 A14 的 1.0 `Report` Schema。
- C1 增量实际图与声明图位于同一 Job 目录的 `actual.json`、`declared.json`；C0 对应文件位于 `job-38eb7d801699492d8e2da9b929233241/`。C1 独立全量动态对照在 `a14-check/target-full/`；C0 原始动态 trace 和 Make 数据库在 `a14-check/baseline-full/`。
- `a14-check/comparison.json`：C1 增量与目标全量的实际图、声明图、发现集合均相同；`behavior/c0.log`、`behavior/c1.log` 是实际 clean build 和运行记录。
- `SHA256SUMS.txt`：本包所有交接文件的 SHA-256，解压后在包根目录执行 `sha256sum -c SHA256SUMS.txt`。

双方仍沿用 E2 1.0。MD-only `Report` 可以按 1.0 消费。实际/声明图保留真实 `source`（`DYNAMIC_TRACE`、`STATIC_INFERENCE`、`MAKE_DATABASE`），作为带哈希原件交接；旧版 Graph Schema 的 `source` 只接受 `MANUAL_FIXTURE`，因此不能把这些真实图声称为通过旧版 Graph 内容校验。B14 的 MDFixer 补丁及 A14 动态复验尚未发生。
