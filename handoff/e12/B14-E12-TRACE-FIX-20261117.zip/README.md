# B14 E12 公共 trace 修复回归

课程包的《02_E12接口联调》第 12 行要求五个阶段使用相同的 `job_id` 和 `trace_id`。原 B14 正式运行的总结果使用 `trace-3ccaf76e466544e9b78f08a0ddffea67`，而五份阶段记录使用 `trace-be956091f9124d32a6ac0bbef6b2b59e`。这项字段差异不符合手册的字面要求。

B14 修复提交为 `e7b8de36f4a800c403b991ed816e93a2f02e52ba`。阶段输出现在从总结果读取公共 trace。原版本新增的 API 断言在五个阶段均失败，修正后 `test_pair14` 的五个测试通过。

B14 在课程服务器用修正版服务通过 HTTP 重新提交原请求。此次隔离运行目录编号为 `replay.2oWBL3pE`。为使 A14 原始复验报告里的补丁 URI 继续可验证，此次在空的独立任务存储里沿用原逻辑 Job ID `job-3b22d208b0e14f9aae3f7b0474eda172`，重新生成的补丁和原补丁逐字节一致。A14 报告和复验原件按原字节读取，复验生产 Job 仍为 `job-d8945cd048d7487babf2b670b52b67e6`。这次回归验证的是 B14 服务修正，A14 的复验来自原正式联调。

新 API 终态为 `SUCCEEDED`，`recheck.accepted=true`。总结果和五阶段均使用 `trace-3ccaf76e466544e9b78f08a0ddffea67`，五阶段的响应头、总结果引用和文件 SHA-256 已核对。

- `draft.json` `6ebb7f18849478ac63751b478ae9606b3a4c23e991ac94667d116969f50b88c5`
- `full-check.json` `2dabe1918a47cca7bd05df36804cce1d73415a5d0abba73468c74a84b62c8998`
- `incremental-check.json` `90b2a83e95a9c3c2ff4a0f0701c46307b30660158370f02f3716e1c0e0e8589b`
- `repair.json` `2996fcf04022267725b495fef4d898fa011d9799fcf8b17ac087b91d965ea9c9`
- `recheck.json` `788aaf1c03837dc552d1d588640ca31e3bfe31e9f4f6793cc65b93aba006d152`
- `result.json` `42b9726e41070960507e87ff6e133f071675f75f8ce954780c080f289b9a5491`
- `state.json` `bf9e0f5d129eb52a0e4d989dae350d14089438abedbb10c320e1cc9b0027150b`

`evidence/rerun/` 保存修正版 API 响应体及采集的响应头。`evidence/request.json` 是提交的原始请求体。`evidence/original/` 和 `evidence/original-after/` 保存原服务回归前后的响应，响应体逐字节一致。原验收 ZIP 保持其已核对的 SHA-256 `ef402a3f96b3a1d3f0e7b53bbe535f9bea38da8e6e30fe0f8098a90e853c6259`。
