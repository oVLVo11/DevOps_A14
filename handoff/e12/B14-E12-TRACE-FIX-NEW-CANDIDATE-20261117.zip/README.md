# B14 → A14 E12 新正式 Job 补丁交接

B14 在课程服务器用修正版 `e7b8de36f4a800c403b991ed816e93a2f02e52ba` 启动正式 API，并通过正常的 `POST /v1/jobs` 创建新 Job `job-d44bbceb4e8a45d4ac1f1b09b370513e`。DRAFT、C0 全量、C1 增量及修复四阶段已成功，各阶段的 `job_id` 和 `trace_id` 一致。B14 API 正在等待 A14 的对应动态复验。请求及下载所得原始响应见包内记录。

修复提交可从 [GitHub 分支](https://github.com/dInG-yAnWen/DevOPs/tree/codex/e12-common-trace) 获取。该提交触发的两项 CI 均通过。[E11-E12 integration](https://github.com/dInG-yAnWen/DevOPs/actions/runs/44047675314)、[E8-E10 teaching validation](https://github.com/dInG-yAnWen/DevOPs/actions/runs/44047675399)。

- 公共 trace `trace-3ccaf76e466544e9b78f08a0ddffea67`
- C1 `37fcadb1eced8d2504b1d5e0bd96f3b8091568b1`
- 配置 ID `386d1bf4dad4c495b810636f4192e5154f50be512c63a0ce7179447d3f9927bc`
- 镜像 ID `sha256:4131a5fadae383e2e0b5c5ea76caa76314833c3195a67058d036df6d85b5ffa4`
- 本轮新 `patch_uri` `artifact://b14-repair/job-d44bbceb4e8a45d4ac1f1b09b370513e/candidate.patch`
- 补丁 SHA-256 `0606c04039cefa3648c0cc4a39d5ebecf7b4b367fdf664dfefc771840f665323`

新补丁字节与上轮一致，交接请使用上面这个新 `patch_uri`。请用已导入的原镜像、同一配置及相同的五项只读挂载，从干净 C1 应用补丁，重新构建、运行并动态重检。预期输出 `12`，剩余 MD 为 `0`。原 MD-only 报告随包提供。

请回传新复验 Job ID、`recheck.json`、`build.log`、`verify.log`、`full-recheck/findings.json`、动态 trace 原件及 SHA-256，并记录退出码、公共 trace、镜像、C1、配置 ID、新 `patch_uri` 和补丁哈希。B14 收到后将使新 Job 进入终态，并核对五阶段、状态及总结果的 trace。
