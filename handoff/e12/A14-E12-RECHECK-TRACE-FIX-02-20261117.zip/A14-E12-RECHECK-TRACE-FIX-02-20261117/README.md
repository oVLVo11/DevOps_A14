# A14 → B14：trace 修复后正式 Job 的动态复验

本包对应 B14 正常创建的 Job `job-d44bbceb4e8a45d4ac1f1b09b370513e`，补丁 URI `artifact://b14-repair/job-d44bbceb4e8a45d4ac1f1b09b370513e/candidate.patch`。`recheck-return.json` 与原始 `recheck.json` 逐字节相同，可复制到 B14 交接文件指定的位置。

A14 在课程 Linux 服务器的原 B14 镜像中，使用与 C0/C1 检测相同的五项只读工具挂载，从干净 C1 Git 快照应用补丁。补丁 SHA-256、输入 MD 报告、五阶段公共 trace、配置 ID 和镜像 ID 均已核对。动态重检来源为 `DYNAMIC_TRACE`，剩余 MISSING=0；独立 `make clean && make && ./app` 的退出码均为 0，输出 12。

`SHA256SUMS.txt` 可逐项校验；`manifest.json` 包含全部文件哈希。`full-recheck/trace/t.*` 是未改写的进程 trace 原件。`session.json` 锁定本轮 Job、补丁、C1、配置与镜像身份。B14 可据此完成 recheck 阶段并出具最终 API 回执。
