# A14 → B14：E12 正式动态复验原件

本包是对 B14 MDFixer Job `job-3b22d208b0e14f9aae3f7b0474eda172` 的 `candidate.patch` 在 A14 课程服务器执行的正式复验。共同 `trace_id`、配置 ID、C1、镜像 ID、补丁 URI 和 SHA-256、A14 复验 Job ID 均见 `session.json`。B14 的 `candidate.patch` 与原 MD 报告字节已单独核对，原件分别随包保存为 `candidate.patch` 和 `input-md.json`。

在原 B14 镜像中、相同五项只读工具挂载下，A14 从干净 C1 Git 快照检查并应用补丁。`git diff` 仅显示 `e3/fixtures/commits/project/Makefile` 的 `main.o` 依赖行增加 `feature.h`。`recheck.py` 执行清理、构建、运行及 BuildChecker 动态重检，返回 `SUCCEEDED`、输出 `12`、剩余 MD `0`。另在独立拷贝中明确执行 `make clean`、`make`、`./app`，三个退出码均为 `0`，输出 `12`。

## B14 核对入口

- `SHA256SUMS.txt`：解压后在包根目录逐项核对。`manifest.json` 记录身份与各原件 SHA-256。
- `recheck.json`：A14 复验 Job、补丁 URI/哈希、配置、动态来源和 MD 数量。
- 根目录 `clean.log`、`build.log`、`verify.log`、`patch-check.log`、`patch-apply.log`：补丁应用和复验脚本的原始日志。
- `full-recheck/findings.json`：动态重检结果，`findings=[]`、构建退出码 `0`；`full-recheck/trace/t.*` 为 7 份原始进程跟踪，Make 数据库、实际图、声明图和项目快照亦在同目录。
- `acceptance/`：另一次 `make clean && make && ./app` 的日志及 `exit-codes.json`；`formal-recheck-container-exit.txt` 和 `acceptance/container-exit.txt` 均记录容器退出码 `0`。
- `toolchain.txt`、`tool-mounts.sha256`：镜像内构建工具版本与同一组只读挂载工具哈希。

本轮真实 `recheck.json` 保留 `source=DYNAMIC_TRACE`。双方沿用 E2 1.0；旧版 `RecheckReport` 内容 Schema 只接受 `MANUAL_FIXTURE`，因此该真实重检按原件及哈希核对，不声称通过人工样例的 `source` 枚举。B14 负责依据收到的证据更新正式任务最终状态。
